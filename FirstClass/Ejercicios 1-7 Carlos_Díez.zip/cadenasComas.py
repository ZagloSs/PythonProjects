cadena = "51,3,6,7,2,4,6,87"
listaNum = list(map(int, cadena.split(",")))

print(listaNum)