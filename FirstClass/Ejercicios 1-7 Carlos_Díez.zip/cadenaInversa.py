cadena = input("Introduce una cadena para invertirla: ")

cadenaInvertida = cadena[::-1]

print(cadenaInvertida)