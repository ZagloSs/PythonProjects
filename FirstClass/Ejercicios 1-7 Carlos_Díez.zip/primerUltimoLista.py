lista = [51,6,3,7,9,5,4,3]
print(f'el primer numero es {lista[0]} y el último es {lista[-1]}')
print(f'el primer numero es {lista[0]} y el último es {lista.pop()}')